# 🔍 Image SERP Checker

批量驗證網頁圖片是否被 Google 圖片搜尋收錄的 CLI 工具，透過 [SerpAPI](https://serpapi.com) 串接 Google Images。

![Python](https://img.shields.io/badge/Python-3.8+-blue?logo=python&logoColor=white)
![License](https://img.shields.io/badge/License-MIT-green)

## 功能特色

- **批量查詢** — 支援 500+ 筆 URL 一次查詢
- **精準比對** — 用 `site:` 指令搜尋 Google Images，比對圖片來源頁面
- **三種輸出** — 互動式 HTML 報表 / Excel (.xlsx) / CSV
- **並行處理** — 多執行緒加速，可自訂並行數與間隔
- **操作控制** — 執行中可暫停 (P) / 中止 (Q)
- **智慧節流** — API 額度用盡自動中止，已完成結果不丟失

## 快速開始

### 1. 安裝

```bash
git clone https://github.com/YOUR_USERNAME/image-serp-checker.git
cd image-serp-checker
pip install -r requirements.txt
```

### 2. 取得 SerpAPI Key

到 [serpapi.com](https://serpapi.com) 註冊帳號（免費方案 100 次/月），複製你的 API Key。

### 3. 執行

```bash
# 測試連線
python image_serp_checker.py --test --key YOUR_SERPAPI_KEY

# 批量查詢 → 互動式 HTML 報表
python image_serp_checker.py -i urls.txt -o report.html --key YOUR_SERPAPI_KEY

# 批量查詢 → Excel
python image_serp_checker.py -i urls.txt -o results.xlsx --key YOUR_SERPAPI_KEY

# 批量查詢 → CSV
python image_serp_checker.py -i urls.txt -o results.csv --key YOUR_SERPAPI_KEY
```

## 輸入格式

建立 `urls.txt`，每行一個網址：

```
https://example.com/page-1
https://example.com/page-2
https://example.com/blog/article-3
```

也支援 CSV 檔案（自動擷取其中的 URL）。

## 輸出範例

### 互動式 HTML 報表

```bash
python image_serp_checker.py -i urls.txt -o report.html --key YOUR_KEY
```

用瀏覽器開啟 `report.html`，包含：

- 📊 統計儀表板（收錄率、圖片數量等）
- 🍩 收錄分佈圓餅圖
- 📶 域名收錄長條圖（Top 20）
- 🔎 可搜尋 / 篩選 / 排序的明細表格
- 📥 一鍵匯出 CSV

### Excel 報表

```bash
python image_serp_checker.py -i urls.txt -o results.xlsx --key YOUR_KEY
```

包含三個工作表：查詢結果（自動上色）、統計摘要、域名統計。

## 參數說明

| 參數 | 說明 | 預設值 |
|------|------|--------|
| `-i, --input` | 輸入檔案 (.txt / .csv) | 必填 |
| `-o, --output` | 輸出檔案 (.html / .xlsx / .csv) | 必填 |
| `--key` | SerpAPI Key（或環境變數 `SERPAPI_KEY`） | - |
| `-c, --concurrency` | 並行查詢數 | 3 |
| `-d, --delay` | 每次查詢間隔（秒） | 1.0 |
| `--hl` | 搜尋語言 | zh-TW |
| `--gl` | 搜尋國家/地區 | tw |
| `--skip-index` | 跳過頁面索引檢查（省一半 credit） | False |
| `-y, --yes` | 跳過確認，直接開始 | False |
| `--test` | 只測試 API Key 連線 | False |

## 環境變數

設定環境變數後可省略 `--key` 參數：

```bash
# Windows CMD
set SERPAPI_KEY=your_api_key_here

# Windows PowerShell
$env:SERPAPI_KEY="your_api_key_here"

# Mac / Linux
export SERPAPI_KEY=your_api_key_here
```

## API 用量

| 模式 | Credit / URL | 說明 |
|------|-------------|------|
| 預設模式 | 2 | 圖片搜尋 + 頁面索引檢查 |
| `--skip-index` | 1 | 只查圖片搜尋 |
| `--test` | 1 | 測試連線用 |

SerpAPI 免費方案每月 100 次查詢。[查看方案](https://serpapi.com/pricing)

## 檢測原理

```
輸入 URL: https://example.com/page-1
    ↓
步驟 1: 呼叫 SerpAPI engine=google_images, q="site:example.com/page-1"
    ↓
步驟 2: 比對 images_results[] 中的 link 欄位是否匹配輸入 URL
    ↓
步驟 3: (選) 呼叫 SerpAPI engine=google, 確認頁面是否已被索引
    ↓
輸出: 收錄狀態 / 圖片數量 / 最佳排名 / 圖片標題 / 來源頁面
```

## 常見問題

### Q: 連線測試出現 SSL 錯誤？
公司網路可能有防火牆攔截 HTTPS。嘗試設定 Proxy：
```bash
set HTTPS_PROXY=http://your-proxy:port
```

### Q: 如何省 API 額度？
加 `--skip-index` 只查圖片收錄，每個 URL 只消耗 1 credit（省一半）。

### Q: 支援多大的批量？
測試過 500+ URL 沒問題。大量查詢建議降低並行數 `-c 2` 避免 API 限流。

## License

MIT License. 詳見 [LICENSE](LICENSE)。
